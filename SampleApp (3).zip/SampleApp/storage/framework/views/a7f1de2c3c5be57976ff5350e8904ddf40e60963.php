投稿フォーム
<?php echo Form::open(['route' => 'upload', 'method' => 'post','files' => true]); ?>

    <div class="form-group">
        <?php echo Form::label('file', '画像投稿', ['class' => 'control-label']); ?>

        <?php echo Form::file('file'); ?>

    </div>
    <div class="form-group m-0">
        <?php echo Form::label('textarea', '投稿コメント', ['class' => 'control-label']); ?>

        <?php echo Form::textarea('comment',null,['class' => 'form-control']); ?>

    </div>   
    <div class="form-group text-center">
        <?php echo Form::submit('投稿', ['class' => 'btn btn-primary my-20']); ?>

    </div>
<?php echo Form::close(); ?>

//画像とコメントをすべて表示
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card-header text-center">
        <img src= <?php echo e(Storage::disk('local')->url($post->image_file_name)); ?> alt="" width=250px height=250px></a>
    </div>
    <div class="card-body p-1">
        <span class="card-title"><?php echo e($post->image_title); ?></span>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\SampleApp\resources\views/welcome.blade.php ENDPATH**/ ?>